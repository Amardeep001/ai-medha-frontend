// src/pages/dashboard/OverviewPage.js
import React from "react";
import Overview from "../components/Overview";

const OverviewPage = () => {
  return <Overview />;
};

export default OverviewPage;
