import React from "react";
import UserManagement from "../components/UserManagement";

const UsersPage = () => {
  return <UserManagement />;
};

export default UsersPage;
