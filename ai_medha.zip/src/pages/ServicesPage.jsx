import React from "react";
import ServiceCatalogue from "../components/ServicesCatalogue";

const ServicesPage = () => {
  return <ServiceCatalogue />;
};

export default ServicesPage;
